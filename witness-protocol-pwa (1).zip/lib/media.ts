// Media handling: EXIF stripping + hashing prep.

import { sha256Hex } from "./crypto"

export interface ProcessedMedia {
  bytes: ArrayBuffer
  mimeType: string
  size: number
  sha256: string
}

/**
 * Re-encode an image through a canvas to drop EXIF/metadata.
 * Falls back to the original bytes if the image cannot be decoded.
 */
export async function stripImageMetadata(file: Blob): Promise<Blob> {
  if (!file.type.startsWith("image/")) return file
  try {
    const bitmap = await createImageBitmap(file)
    const canvas = document.createElement("canvas")
    canvas.width = bitmap.width
    canvas.height = bitmap.height
    const ctx = canvas.getContext("2d")
    if (!ctx) return file
    ctx.drawImage(bitmap, 0, 0)
    bitmap.close?.()
    const outType = file.type === "image/png" ? "image/png" : "image/jpeg"
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob((b) => resolve(b), outType, 0.92),
    )
    return blob ?? file
  } catch {
    // If decoding fails (e.g. unsupported format), keep the original.
    return file
  }
}

/**
 * Prepare a file for encrypted storage:
 * strips metadata from images, then computes a SHA-256 hash of the bytes.
 */
export async function processMedia(
  file: Blob,
  isImage: boolean,
): Promise<ProcessedMedia> {
  const cleaned = isImage ? await stripImageMetadata(file) : file
  const bytes = await cleaned.arrayBuffer()
  const sha256 = await sha256Hex(bytes)
  return {
    bytes,
    mimeType: cleaned.type || file.type || "application/octet-stream",
    size: bytes.byteLength,
    sha256,
  }
}

export function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / (1024 * 1024)).toFixed(1)} MB`
}
